package com.newmysmileQR.Utility.Notification;


public class Config {
    // broadcast receiver intent filters
    static final String REGISTRATION_COMPLETE = "registrationComplete";
    static final String PUSH_NOTIFICATION = "pushNotification";
}
